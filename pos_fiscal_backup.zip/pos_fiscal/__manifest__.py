{
    'name': 'POS Fiscal',
    'version': '2.0',
    'category': 'Point of Sale',
    'summary': 'Enhanced fiscal management for POS with auto-reconciliation and invoicing',
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'point_of_sale',
        'stock',
        'web',
        'mail',
        'pos_etta',  # Added for inventory picking integration
    ],
    'external_dependencies': {
        'python': [],
    },
    'data': [
        'security/ir.model.access.csv',
        # 'data/cron_data.xml',
        'data/server_action.xml',
        'views/pos_device_views.xml',
        'views/pos_invoice_views.xml',
        'views/pos_refund_views.xml',
        'views/pos_zreport_views.xml',
        'views/pos_fiscal_menus.xml',
        'views/pos_fs_check_wizard.xml',
        'views/pos_fs_check_wizard_enhanced.xml',
        'views/pos_daily_report_views.xml',
        'views/pos_change_log_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'pos_fiscal/static/src/js/pos_device_sync.js',
            'pos_fiscal/static/src/js/pos_invoice_sync.js',
            'pos_fiscal/static/src/js/pos_refund_sync.js',
            "pos_fiscal/static/src/xml/pos_device_sync_template.xml",
        ],
    },
    'installable': True,
    'auto_install': False,
}

