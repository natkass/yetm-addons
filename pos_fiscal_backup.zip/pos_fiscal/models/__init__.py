from . import pos_device
from . import pos_invoice
from . import pos_refund
from . import pos_zreport
from . import stock_picking  # Adds pos_order_id field to stock.picking
from . import pos_order  # Must be loaded before pos_order_reconcile_new
from . import pos_order_reconcile_new
