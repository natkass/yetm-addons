from odoo import models, fields, api
import logging
from datetime import date, datetime, timedelta
from collections import defaultdict

_logger = logging.getLogger(__name__)

class PosPaymentMethod(models.Model):
    _inherit = 'pos.payment.method'

    def get_payment_method_id(self, payment_method, company_id, session_id):
        _logger.info("🚀 Entering get_payment_method_id with payment_method=%s, company_id=%s, session_id=%s", payment_method, company_id, session_id)
        try:
            normalized_payment = payment_method.strip().lower()
            session = self.env['pos.session'].browse(session_id) if session_id else None
            if not session:
                _logger.warning("⚠️ No session found for session_id: %s", session_id)
                session = self.env['pos.session'].search([('company_id', '=', company_id), ('state', '=', 'closed')], order='start_at desc', limit=1)
                if not session:
                    _logger.error("❌ No session found for company_id=%s", company_id)
                    return None, None, None
                session_id = session.id

            config = session.config_id
            payment = self.search([
                ('name', '=ilike', payment_method),
                ('company_id', '=', company_id),
            ], limit=1)
            if not payment:
                _logger.warning("⚠️ No payment method found for '%s' in company_id=%s", payment_method, company_id)
                payment = config.payment_method_ids.filtered(lambda pm: pm.company_id.id == company_id)[:1]
                if not payment:
                    payment = self.search([
                        ('name', '=ilike', 'Cash'),
                        ('company_id', '=', company_id),
                    ], limit=1)
                    if not payment:
                        _logger.error("❌ No default 'Cash' payment method found for company_id=%s", company_id)
                        return None, None, None

            if payment not in config.payment_method_ids:
                _logger.warning("⚠️ Payment method '%s' not in config ID=%s", payment.name, config.id)
                payment = config.payment_method_ids.filtered(lambda pm: pm.company_id.id == company_id)[:1] or self.search([
                    ('name', '=ilike', 'Cash'),
                    ('company_id', '=', company_id),
                ], limit=1)
                if not payment:
                    return None, None, None

            journal_name = payment.journal_id.name if payment.journal_id else None
            _logger.info("✅ Found payment method: %s (ID=%s), Journal: %s", payment.name, payment.id, journal_name)
            return payment.id, session_id, journal_name

        except Exception as e:
            _logger.exception("❌ Error in get_payment_method_id for '%s': %s", payment_method, str(e))
            return None, None, None

class PosOrder(models.Model):
    _inherit = 'pos.order'

    @api.model
    def run_reconciliation_check(self, target_mrc=None, start_date=None, end_date=None):
        """
        Enhanced reconciliation process with improved duplicate handling and invoice-based validation.
        
        This method ensures:
        1. Invoice (EJ) data is the source of truth
        2. FS numbers are unique per MRC
        3. Duplicates are resolved based on invoice matching
        4. Complete data synchronization from invoice to order
        """
        # Default values for testing
        if not target_mrc:
            target_mrc = "URB0000380"
        if not start_date:
            start_date = "2025-07-12"
        if not end_date:
            end_date = "2025-07-12"
        
        _logger.info("🚀 Starting enhanced reconciliation for MRC: %s from %s to %s", target_mrc, start_date, end_date)

        # Convert string dates to datetime.date if necessary
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d").date()

        # Initialize performance metrics
        start_time = datetime.now()
        metrics = {
            'duplicates_found': 0,
            'duplicates_resolved': 0,
            'orders_created': 0,
            'orders_updated': 0,
            'orders_cancelled': 0,
            'orphans_linked': 0,
        }

        # Fetch device
        device = self.env['pos.device'].search([('mrc', '=', target_mrc)], limit=1)
        if not device:
            _logger.error("❌ No POS Device found with MRC: %s", target_mrc)
            return {'status': 'error', 'message': f"No POS Device found with MRC: {target_mrc}"}

        # Create daily report early for logging
        daily_report = self.env['pos.daily.report'].create({
            'date': start_date,
            'fiscal_mrc': target_mrc,
            'company_id': self.env.company.id,
        })

        # Fetch POS Orders
        pos_orders = self.search_read(
            [('fiscal_mrc', '=', target_mrc),
             ('date_order', '>=', start_date),
             ('date_order', '<=', end_date)],
            ['id', 'fiscal_mrc', 'fs_no', 'date_order', 'amount_total', 'state', 'pos_reference']
        )
        _logger.info("✅ %d POS Orders fetched", len(pos_orders))

        # Fetch POS Invoices (Source of Truth)
        invoice_model = self.env['pos.invoice']
        pos_invoices = invoice_model.search_read(
            [('device_id', '=', device.id),
             ('date', '>=', start_date),
             ('date', '<=', end_date)],
            ['id', 'fsNumber', 'totalWithTax', 'date', 'time', 'paymentType', 'cashierName', 
             'buyerName', 'referenceNumber', 'totalTax', 'totalPaid', 'change', 'headerMemo']
        )
        _logger.info("✅ %d POS Invoices fetched (Source of Truth)", len(pos_invoices))

        # Fetch POS Refunds
        refund_model = self.env['pos.refund']
        pos_refunds = refund_model.search_read(
            [('device_id', '=', device.id),
             ('date', '>=', start_date),
             ('date', '<=', end_date)],
            ['id', 'rfdNumber', 'totalWithTax', 'date', 'paymentType', 'cashierName', 'buyerName']
        )
        refund_total = sum(refund['totalWithTax'] for refund in pos_refunds)
        _logger.info("✅ %d POS Refunds fetched, Total: %.2f", len(pos_refunds), refund_total)

        # Fetch Z-Reports with exception handling
        zreport_model = self.env['pos.zreport']
        excluded_zreport_ids = self.env['pos.zreport.exception'].get_excluded_zreport_ids(target_mrc, start_date, end_date)
        
        all_zreports = zreport_model.search_read(
            [('device_id', '=', device.id),
             ('date', '>=', start_date),
             ('date', '<=', end_date)],
            ['id', 'salesTotal', 'rfdSalesTotal', 'date']
        )
        
        # Filter and deduplicate Z-reports
        zreports = self._process_zreports(all_zreports, excluded_zreport_ids)
        z_sales_total = sum(z['salesTotal'] for z in zreports)
        z_refund_total = sum(z['rfdSalesTotal'] for z in zreports)
        _logger.info("✅ %d Z-Reports processed, Sales: %.2f, Refunds: %.2f", 
                    len(zreports), z_sales_total, z_refund_total)

        # Build comprehensive invoice map (Source of Truth)
        invoice_map = self._build_invoice_map(pos_invoices)
        
        # Build order map for comparison
        order_map = self._build_order_map(pos_orders)

        # Phase 1: Enhanced Duplicate Resolution
        _logger.info("🔍 Phase 1: Enhanced Duplicate FS Resolution")
        duplicate_stats = self._resolve_duplicate_fs_numbers(
            target_mrc, start_date, end_date, invoice_map, daily_report
        )
        metrics.update(duplicate_stats)

        # Phase 2: Orphan Order Processing
        _logger.info("🔍 Phase 2: Processing Orphan Orders")
        orphan_stats = self._process_orphan_orders(
            target_mrc, start_date, end_date, invoice_map, daily_report
        )
        metrics['orphans_linked'] = orphan_stats['linked']
        metrics['orders_cancelled'] += orphan_stats['cancelled']

        # Phase 3: Invoice-Based Validation
        _logger.info("🔍 Phase 3: Invoice-Based Validation and Synchronization")
        validation_stats = self._validate_orders_against_invoices(
            invoice_map, order_map, target_mrc, start_date, end_date, daily_report
        )
        metrics['orders_created'] += validation_stats['created']
        metrics['orders_updated'] += validation_stats['updated']

        # Phase 4: Cross-date reconciliation - match orders by FS number across all dates
        _logger.info("🔍 Phase 4: Cross-date reconciliation for mismatched orders")
        cross_date_stats = self._reconcile_cross_date_orders(
            invoice_map, target_mrc, start_date, end_date, daily_report
        )
        metrics['orders_updated'] += cross_date_stats['updated']
        metrics['orders_cancelled'] += cross_date_stats['cancelled']
        
        # Phase 5: Ensure all orders with MRC and FS are set to 'invoiced' state
        _logger.info("🔍 Phase 5: Updating state for orders with fiscal data")
        state_update_count = self._update_orders_to_invoiced_state(target_mrc, start_date, end_date)
        _logger.info("✅ Updated %d orders to 'invoiced' state", state_update_count)

        # Phase 6: Analyze session balances for reporting
        # Note: Session balance analysis skipped as reconciliation can span multiple sessions
        _logger.info("🔍 Phase 6: Session balance analysis skipped (multi-session reconciliation)")

        # Calculate final statistics
        order_count = len(pos_orders)
        invoice_count = len(pos_invoices)
        
        # Recalculate totals after modifications
        updated_orders = self.search_read(
            [('fiscal_mrc', '=', target_mrc),
             ('date_order', '>=', start_date),
             ('date_order', '<=', end_date),
             ('state', '!=', 'cancel')],
            ['amount_total']
        )
        order_total = sum(order['amount_total'] for order in updated_orders)
        invoice_total = sum(invoice['totalWithTax'] for invoice in pos_invoices)
        
        net_order_total = order_total - refund_total
        net_invoice_total = invoice_total - refund_total
        net_zreport_total = z_sales_total - z_refund_total
        
        # Update daily report
        daily_report.write({
            'pos_order_count': len(updated_orders),
            'invoice_count': invoice_count,
            'refund_count': len(pos_refunds),
            'unmatched_fs_count': validation_stats.get('unmatched', 0),
            'session_total': order_total,
            'z_report_total': z_sales_total,
            'refund_total': refund_total,
            'net_order_total': net_order_total,
            'net_invoice_total': net_invoice_total,
            'zreport_sales_total': z_sales_total,
            'zreport_refund_total': z_refund_total,
            'net_zreport_total': net_zreport_total,
            'total_mismatch': abs(net_order_total - net_zreport_total),
            'recreated_orders': metrics['orders_created'],
            'updated_orders': metrics['orders_updated'],
        })

        # Cancel any posted orders without fiscal data
        cancelled_count = self._cancel_unreconciled_orders(target_mrc, start_date, end_date, daily_report)
        metrics['orders_cancelled'] += cancelled_count
        
        # Update the cancelled orders count in the daily report
        daily_report.write({
            'cancelled_orders': metrics['orders_cancelled']
        })

        # Calculate processing time
        processing_time = (datetime.now() - start_time).total_seconds()
        
        # Log comprehensive summary
        _logger.info("=" * 60)
        _logger.info("📊 RECONCILIATION SUMMARY")
        _logger.info("=" * 60)
        _logger.info("📦 Orders: %d | Invoices: %d | Refunds: %d", 
                    len(updated_orders), invoice_count, len(pos_refunds))
        _logger.info("💸 Totals - Order: %.2f | Invoice: %.2f | Z-Report: %.2f", 
                    order_total, invoice_total, z_sales_total)
        _logger.info("🔄 Changes - Created: %d | Updated: %d | Cancelled: %d", 
                    metrics['orders_created'], metrics['orders_updated'], metrics['orders_cancelled'])
        _logger.info("🔗 Duplicates: %d found, %d resolved | Orphans linked: %d", 
                    metrics['duplicates_found'], metrics['duplicates_resolved'], metrics['orphans_linked'])
        _logger.info("⏱️ Processing time: %.2f seconds", processing_time)
        _logger.info("=" * 60)

        return {
            'status': 'success',
            'daily_report_id': daily_report.id,
            'metrics': metrics,
            'processing_time': processing_time,
            'order_count': len(updated_orders),
            'invoice_count': invoice_count,
            'order_total': order_total,
            'invoice_total': invoice_total,
            'net_order_total': net_order_total,
            'net_invoice_total': net_invoice_total,
            'net_zreport_total': net_zreport_total,
            'count_match': len(updated_orders) == invoice_count,
            'total_match': abs(net_order_total - net_zreport_total) <= 0.01,
        }

    def _cancel_unreconciled_orders(self, target_mrc, start_date, end_date, daily_report):
        """
        Cancel posted orders that don't have fs_no and mrc after reconciliation.
        """
        _logger.info("🔍 Checking for posted orders without fiscal data after reconciliation...")
        
        # Find posted orders without fs_no and mrc
        unreconciled_orders = self.search([
            ('fiscal_mrc', 'in', [False, '']),
            ('fs_no', 'in', [False, '']),
            ('date_order', '>=', start_date),
            ('date_order', '<=', end_date),
        ])
        _logger.info("🔍 Found %d posted orders without fiscal data", len(unreconciled_orders))
        cancelled_count = 0
        for order in unreconciled_orders:
            self._cancel_order(order, "Posted order without fiscal data after reconciliation", daily_report)
            cancelled_count += 1
        
        if cancelled_count > 0:
            _logger.info("❌ Cancelled %d posted orders without fiscal data", cancelled_count)
        else:
            _logger.info("✅ No posted orders without fiscal data found")
            
        return cancelled_count

    def _process_zreports(self, all_zreports, excluded_ids):
        """Process Z-reports with deduplication by date, summing totals."""
        # Filter out excluded Z-reports
        filtered_reports = [z for z in all_zreports if z['id'] not in excluded_ids]

        # Aggregate by date
        date_zreport_map = {}
        for zreport in filtered_reports:
            z_date = zreport['date']
            if z_date not in date_zreport_map:
                # First occurrence — copy all values
                date_zreport_map[z_date] = {
                    'id': zreport['id'],
                    'date': z_date,
                    'salesTotal': zreport.get('salesTotal', 0),
                    'rfdSalesTotal': zreport.get('rfdSalesTotal', 0),
                }
            else:
                # Sum totals, and keep highest ID
                existing = date_zreport_map[z_date]
                existing['salesTotal'] += zreport.get('salesTotal', 0)
                existing['rfdSalesTotal'] += zreport.get('rfdSalesTotal', 0)
                if zreport['id'] > existing['id']:
                    existing['id'] = zreport['id']

                _logger.info(
                    "➕ Summing Z-report for date %s: ID %d (Sales %.2f, Refunds %.2f)",
                    z_date,
                    zreport['id'],
                    zreport.get('salesTotal', 0),
                    zreport.get('rfdSalesTotal', 0)
                )

        return list(date_zreport_map.values())

    def _build_invoice_map(self, invoices):
        """Build comprehensive invoice map with validation."""
        invoice_map = {}
        duplicate_invoices = defaultdict(list)
        
        for inv in invoices:
            fs_number = inv.get('fsNumber')
            if not fs_number:
                _logger.warning("⚠️ Invoice without FS number: ID %s", inv['id'])
                continue
                
            # Standardize FS number format
            fs_key = self._standardize_fs_number(fs_number)
            if not fs_key:
                _logger.warning("⚠️ Invalid FS number format: %s", fs_number)
                continue
            
            if fs_key in invoice_map:
                duplicate_invoices[fs_key].append(inv)
                _logger.warning("⚠️ Duplicate invoice FS %s found, keeping first (ID: %s)", 
                              fs_key, invoice_map[fs_key]['id'])
            else:
                invoice_map[fs_key] = inv
        
        if duplicate_invoices:
            _logger.warning("⚠️ Found %d duplicate invoice FS numbers", len(duplicate_invoices))
        
        return invoice_map

    def _build_order_map(self, orders):
        """Build order map with standardized FS numbers."""
        order_map = {}
        duplicate_orders = defaultdict(list)
        
        for order in orders:
            if order['state'] == 'cancel':
                continue
                
            fs_no = order.get('fs_no')
            if not fs_no:
                continue
                
            fs_key = self._standardize_fs_number(fs_no)
            if not fs_key:
                continue
            
            if fs_key in order_map:
                duplicate_orders[fs_key].append(order)
            else:
                order_map[fs_key] = order
        
        return order_map

    def _standardize_fs_number(self, fs_number):
        """Standardize FS number to integer for consistent comparison."""
        if not fs_number:
            return None
        try:
            # Convert to string, strip whitespace, remove leading zeros
            fs_str = str(fs_number).strip().lstrip('0')
            if not fs_str or not fs_str.isdigit():
                return None
            return int(fs_str)
        except (ValueError, TypeError):
            return None

    def _resolve_duplicate_fs_numbers(self, target_mrc, start_date, end_date, invoice_map, daily_report):
        """
        Enhanced duplicate resolution that:
        1. Finds ALL duplicates with same FS number
        2. Compares each against invoice data
        3. Keeps ONLY the order matching invoice
        4. Cancels all non-matching duplicates
        """
        stats = {'duplicates_found': 0, 'duplicates_resolved': 0, 'orders_cancelled': 0}
        
        # Find all duplicate FS numbers
        groups = self.env['pos.order'].read_group(
            domain=[
                ('fs_no', '!=', False),
                ('fiscal_mrc', '=', target_mrc),
                ('date_order', '>=', start_date),
                ('date_order', '<=', end_date),
                ('state', 'in', ['paid', 'done'])
            ],
            fields=['fs_no'],
            groupby=['fs_no'],
            lazy=False
        )
        
        duplicate_groups = [g for g in groups if g['__count'] > 1]
        stats['duplicates_found'] = len(duplicate_groups)
        
        for dup_group in duplicate_groups:
            fs_no = dup_group['fs_no']
            _logger.info("📋 Processing duplicate FS: %s (Count: %d)", fs_no, dup_group['__count'])
            
            # Get all orders with this FS number
            duplicate_orders = self.env['pos.order'].search([
                ('fs_no', '=', fs_no),
                ('fiscal_mrc', '=', target_mrc),
                ('date_order', '>=', start_date),
                ('date_order', '<=', end_date),
                ('state', 'in', ['paid', 'done'])
            ])
            
            # Find matching invoice
            fs_key = self._standardize_fs_number(fs_no)
            invoice_data = invoice_map.get(fs_key)
            
            if invoice_data:
                # Score each order against invoice
                best_match = self._find_best_matching_order(duplicate_orders, invoice_data)
                
                if best_match:
                    # Keep best match, cancel others
                    for order in duplicate_orders:
                        if order.id != best_match.id:
                            self._cancel_order(order, f"Duplicate of FS {fs_no}, keeping order {best_match.id}", daily_report)
                            stats['orders_cancelled'] += 1
                            stats['duplicates_resolved'] += 1
                    
                    # Update best match to exactly match invoice
                    if not self._sync_order_with_invoice(best_match, invoice_data, daily_report):
                        _logger.warning("⚠️ Failed to sync best match order %s", best_match.id)
                else:
                    # No good match, cancel all and mark for recreation
                    _logger.warning("⚠️ No matching order for invoice FS %s, cancelling all duplicates", fs_no)
                    for order in duplicate_orders:
                        self._cancel_order(order, f"No match with invoice FS {fs_no}", daily_report)
                        stats['orders_cancelled'] += 1
                    stats['duplicates_resolved'] += 1
            else:
                # No invoice, keep first order only
                _logger.warning("⚠️ No invoice for duplicate FS %s, keeping first order", fs_no)
                for idx, order in enumerate(duplicate_orders):
                    if idx > 0:
                        self._cancel_order(order, f"Duplicate without invoice, FS {fs_no}", daily_report)
                        stats['orders_cancelled'] += 1
                stats['duplicates_resolved'] += 1
        
        return stats

    def _find_best_matching_order(self, orders, invoice_data):
        """Find order that best matches invoice data."""
        best_match = None
        best_score = 0
        
        for order in orders:
            score = 0
            
            # Amount match (highest priority)
            amount_diff = abs(order.amount_total - invoice_data['totalWithTax'])
            if amount_diff < 0.01:
                score += 100  # Exact match
            elif amount_diff < 1.0:
                score += 50   # Close match
            elif amount_diff < 10.0:
                score += 10   # Reasonable match
            
            # Date match
            order_date = order.date_order.date() if hasattr(order.date_order, 'date') else order.date_order
            invoice_date = fields.Date.from_string(invoice_data['date'])
            if order_date == invoice_date:
                score += 20
            
            # Reference number match
            if order.pos_reference and invoice_data.get('referenceNumber'):
                if order.pos_reference == invoice_data['referenceNumber']:
                    score += 30
            
            # Has complete data
            if order.partner_id:
                score += 5
            if order.payment_ids:
                score += 5
            
            if score > best_score:
                best_match = order
                best_score = score
        
        # Only return if score is reasonable
        if best_score >= 50:
            _logger.info("✅ Best match for FS %s: Order %s (score: %d)", 
                        invoice_data['fsNumber'], best_match.id if best_match else None, best_score)
            return best_match
        
        return None

    def _process_orphan_orders(self, target_mrc, start_date, end_date, invoice_map, daily_report):
        """Process orders without fiscal_mrc or fs_no."""
        stats = {'linked': 0, 'cancelled': 0}
        
        orphan_orders = self.with_context(active_test=False).search([
            '|',
            ('fiscal_mrc', '=', False),
            ('fs_no', '=', False),
            ('date_order', '>=', start_date),
            ('date_order', '<=', end_date),
            ('state', 'in', ['paid', 'done']),
        ])
        
        _logger.info("🔍 Found %d orphan orders to process", len(orphan_orders))
        
        for order in orphan_orders:
            matched = False
            
            # Try to match by reference number
            if order.pos_reference:
                for fs_key, inv_data in invoice_map.items():
                    if inv_data.get('referenceNumber') == order.pos_reference:
                        # Link orphan to invoice
                        fs_str = str(fs_key).zfill(8)
                        _logger.info("🔗 Linking orphan order %s to invoice FS %s", order.id, fs_str)
                        
                        order.write({
                            'fiscal_mrc': target_mrc,
                            'fs_no': fs_str,
                        })
                        
                        # Sync with invoice data
                        if not self._sync_order_with_invoice(order, inv_data, daily_report):
                            _logger.warning("⚠️ Failed to sync orphan order %s", order.id)
                        
                        self.env['pos.change.log'].log_change(
                            pos_order_id=order.id,
                            fs_no=fs_str,
                            fiscal_mrc=target_mrc,
                            change_type='linked',
                            old_value='orphan',
                            new_value='linked to invoice',
                            daily_report_id=daily_report.id
                        )
                        stats['linked'] += 1
                        matched = True
                        break
            
            # If no match, cancel orphan
            if not matched:
                self._cancel_order(order, "Orphan order without matching invoice", daily_report)
                stats['cancelled'] += 1
        
        return stats

    def _validate_orders_against_invoices(self, invoice_map, order_map, target_mrc, start_date, end_date, daily_report):
        """
        Validate all orders against invoices:
        1. Create orders for unmatched invoices
        2. Update orders with mismatched data
        3. Ensure complete data synchronization
        """
        stats = {'created': 0, 'updated': 0, 'unmatched': 0}
        processed_fs = set()
        
        for fs_key, invoice_data in invoice_map.items():
            if fs_key in processed_fs:
                continue
            
            existing_order = order_map.get(fs_key)
            
            if not existing_order:
                # Check for order with various FS formats
                fs_variations = [
                    str(fs_key),
                    str(fs_key).zfill(8),
                    str(fs_key).lstrip('0'),
                ]
                
                existing_order_rec = None
                for fs_var in fs_variations:
                    existing_order_rec = self.search([
                        ('fs_no', '=', fs_var),
                        ('fiscal_mrc', '=', target_mrc),
                        ('state', '!=', 'cancel')
                    ], limit=1)
                    if existing_order_rec:
                        break
                
                if existing_order_rec:
                    # Update existing order with complete invoice data
                    if self._sync_order_with_invoice(existing_order_rec, invoice_data, daily_report):
                        stats['updated'] += 1
                        _logger.info("✅ Successfully updated order %s with invoice FS %s", 
                                    existing_order_rec.id, invoice_data['fsNumber'])
                    else:
                        _logger.error("❌ Failed to update order %s", existing_order_rec.id)
                        stats['unmatched'] += 1
                else:
                    # Create new order from invoice
                    if self._create_order_from_invoice(invoice_data, target_mrc, daily_report):
                        stats['created'] += 1
                    else:
                        stats['unmatched'] += 1
            else:
                # Check if update needed - ALWAYS update to ensure complete sync
                order_rec = self.browse(existing_order['id'])
                if self._needs_update(order_rec, invoice_data):
                    if self._sync_order_with_invoice(order_rec, invoice_data, daily_report):
                        stats['updated'] += 1
                        _logger.info("✅ Updated existing order %s", order_rec.id)
                    else:
                        _logger.error("❌ Failed to update order %s", order_rec.id)
            
            processed_fs.add(fs_key)
        
        return stats
    
    def _reconcile_cross_date_orders(self, invoice_map, target_mrc, start_date, end_date, daily_report):
        """
        Reconcile orders that might have wrong dates by searching for their FS numbers
        across ALL invoices (not just the date range).
        Invoice is the source of truth - update order date and data if found elsewhere.
        """
        stats = {'updated': 0, 'checked': 0, 'cancelled': 0}
        
        # Get all non-cancelled orders for the period
        all_orders = self.search([
            ('fiscal_mrc', '=', target_mrc),
            ('date_order', '>=', start_date),
            ('date_order', '<=', end_date),
            ('state', '!=', 'cancel')
        ])
        
        _logger.info("🔍 Cross-date reconciliation: Checking %d orders", len(all_orders))
        
        for order in all_orders:
            stats['checked'] += 1
            
            # First check if order has matching invoice in current date range
            has_matching_invoice = False
            if order.fs_no:
                fs_key = self._standardize_fs_number(order.fs_no)
                if fs_key and fs_key in invoice_map:
                    has_matching_invoice = True
                    continue  # Already matched in current date range
            
            # If not found in date range, search across ALL invoices by FS number
            if order.fs_no and not has_matching_invoice:
                _logger.info("🔍 Order %s (FS: %s) not in date range, searching all invoices...", 
                            order.name, order.fs_no)
                
                # Search for invoice with this FS number across all dates
                matching_invoice = self.env['pos.invoice'].search([
                    ('fsNumber', '=', order.fs_no),
                    ('device_id.mrc', '=', target_mrc)
                ], limit=1)
                
                if not matching_invoice:
                    # Try with different FS number formats
                    fs_variations = [
                        str(order.fs_no),
                        str(order.fs_no).zfill(8),
                        str(order.fs_no).lstrip('0'),
                        int(order.fs_no) if str(order.fs_no).isdigit() else None
                    ]
                    
                    for fs_var in fs_variations:
                        if fs_var:
                            matching_invoice = self.env['pos.invoice'].search([
                                ('fsNumber', '=', str(fs_var)),
                                ('device_id.mrc', '=', target_mrc)
                            ], limit=1)
                            if matching_invoice:
                                break
                
                if matching_invoice:
                    _logger.warning("📅 Found invoice FS %s on different date: %s (order date: %s)", 
                                  matching_invoice.fsNumber, matching_invoice.date, order.date_order.date())
                    
                    # Prepare invoice data for sync
                    invoice_data = {
                        'id': matching_invoice.id,
                        'fsNumber': matching_invoice.fsNumber,
                        'date': matching_invoice.date,
                        'totalWithTax': matching_invoice.totalWithTax,
                        'totalTax': matching_invoice.totalTax,
                        'referenceNumber': matching_invoice.referenceNumber,
                        'paymentType': matching_invoice.paymentType,
                    }
                    
                    # Update order with correct date and all invoice data
                    _logger.info("🔄 Updating order %s with correct date from invoice", order.name)
                    
                    # Update the order's date and sync with invoice
                    if self._sync_order_with_invoice(order, invoice_data, daily_report):
                        stats['updated'] += 1
                        _logger.info("✅ Successfully updated order %s with cross-date invoice FS %s", 
                                    order.id, matching_invoice.fsNumber)
                    else:
                        _logger.error("❌ Failed to update order %s with cross-date invoice", order.id)
                else:
                    # No invoice found anywhere - this is truly an orphan order
                    _logger.warning("❌ Order %s (FS: %s) has no matching invoice anywhere - cancelling", 
                                  order.name, order.fs_no)
                    reason = f"No matching invoice found anywhere (FS: {order.fs_no})"
                    self._cancel_order(order, reason, daily_report)
                    stats['cancelled'] += 1
            elif not order.fs_no:
                # Order without FS number - likely needs to be cancelled
                _logger.warning("❌ Order %s has no FS number - cancelling", order.name)
                reason = "Order without FS number (no invoice reference)"
                self._cancel_order(order, reason, daily_report)
                stats['cancelled'] += 1
        
        _logger.info("📊 Cross-date reconciliation complete: %d checked, %d updated, %d cancelled", 
                    stats['checked'], stats['updated'], stats['cancelled'])
        
        return stats
    
    def _update_orders_to_invoiced_state(self, target_mrc, start_date, end_date):
        """
        Ensure all orders with MRC and FS number are in 'invoiced' state.
        This is the final cleanup to ensure correct state.
        """
        # Find orders with fiscal data that are not in 'invoiced' state
        orders_to_update = self.search([
            ('fiscal_mrc', '=', target_mrc),
            ('fs_no', '!=', False),
            ('date_order', '>=', start_date),
            ('date_order', '<=', end_date),
            ('state', 'not in', ['invoiced', 'cancel'])
        ])
        
        update_count = 0
        for order in orders_to_update:
            if order.fiscal_mrc and order.fs_no:
                _logger.info("📝 Updating order %s to 'invoiced' state (MRC: %s, FS: %s)", 
                            order.name, order.fiscal_mrc, order.fs_no)
                
                # Use SQL to bypass validation
                self.env.cr.execute("""
                    UPDATE pos_order 
                    SET state = 'invoiced' 
                    WHERE id = %s
                """, (order.id,))
                
                update_count += 1
        
        if update_count > 0:
            # Invalidate the ORM cache for updated records
            orders_to_update.invalidate_recordset(['state'])
        
        return update_count

    def _needs_update(self, order, invoice_data):
        """Check if order needs update from invoice data - comprehensive check."""
        # Always update to ensure complete synchronization
        _logger.info("🔍 Checking if order %s needs update from invoice FS %s", 
                    order.id, invoice_data['fsNumber'])
        
        # Check amount differences
        if abs(order.amount_total - invoice_data['totalWithTax']) > 0.01:
            _logger.info("  💰 Amount mismatch: %.2f vs %.2f", 
                        order.amount_total, invoice_data['totalWithTax'])
            return True
        
        # Check tax amount
        if abs(order.amount_tax - invoice_data.get('totalTax', 0.0)) > 0.01:
            _logger.info("  💰 Tax mismatch: %.2f vs %.2f", 
                        order.amount_tax, invoice_data.get('totalTax', 0.0))
            return True
        
        # Check if missing important fields
        if not order.fs_no or not order.fiscal_mrc:
            _logger.info("  ⚠️ Missing fs_no or fiscal_mrc")
            return True
        
        # Check reference fields
        if order.pos_reference != invoice_data.get('referenceNumber'):
            _logger.info("  📋 Reference mismatch: %s vs %s", 
                        order.pos_reference, invoice_data.get('referenceNumber'))
            return True
        
        # Check line count
        invoice_rec = self.env['pos.invoice'].browse(invoice_data['id'])
        if len(order.lines) != len(invoice_rec.line_ids):
            _logger.info("  📦 Line count mismatch: %d vs %d", 
                        len(order.lines), len(invoice_rec.line_ids))
            return True
        
        # Check payment method sync
        if invoice_data.get('paymentType'):
            if not order.payment_ids:
                _logger.info("  💳 No payments on order")
                return True
            payment = order.payment_ids[0]
            if payment.payment_method_id.name != invoice_data['paymentType']:
                _logger.info("  💳 Payment method mismatch: %s vs %s", 
                            payment.payment_method_id.name, invoice_data['paymentType'])
                return True

        # Check if date matches invoice date
        order_date = order.date_order.date() if hasattr(order.date_order, 'date') else order.date_order
        invoice_date = fields.Date.from_string(invoice_data['date'])
        if order_date != invoice_date:
            _logger.info("  📅 Date mismatch: %s vs %s", order_date, invoice_date)
            return True

        # No mismatch found - skip update to avoid double pickings and unnecessary updates
        _logger.info("  ✅ Perfect match - skipping update for order %s (FS: %s)",
                    order.id, order.fs_no)
        return False

    def _sync_order_with_invoice(self, order, invoice_data, daily_report):
        """
        Complete synchronization of ALL invoice fields to existing order.
        This method completely replaces order data with invoice data.
        """
        try:
            # Log the update attempt
            _logger.info("🔄 Starting complete sync for order %s with invoice FS %s", 
                        order.id, invoice_data['fsNumber'])
            
            # Store old values for logging
            old_amount = order.amount_total
            old_lines_count = len(order.lines)
            old_payment_count = len(order.payment_ids)
            old_state = order.state
            old_invoice_id = order.account_move.id if order.account_move else None
            
            # Get invoice record for complete data
            invoice_rec = self.env['pos.invoice'].browse(invoice_data['id'])

            # Determine session using FS number BEFORE method (uses invoice.date, not reconciliation date)
            invoice_date = fields.Datetime.from_string(invoice_data['date']).date()
            session = self._find_session_by_fs_before(
                invoice_data['fsNumber'],
                order.fiscal_mrc or invoice_rec.device_id.mrc,
                invoice_date
            )

            if not session:
                _logger.error("❌ Cannot find session for order update")
                return False
            
            # Prepare COMPLETE order values using existing method
            order_vals = self._prepare_pos_order_vals(
                invoice_rec, 
                order.fiscal_mrc or invoice_rec.device_id.mrc,
                session.id
            )
            
            if not order_vals:
                _logger.error("❌ Cannot prepare order values for update")
                return False
            
            # Step 1: If there's an existing invoice, remove it first
            if order.account_move:
                _logger.info("🗑️ Removing existing invoice %s before updating order", order.account_move.name)
                try:
                    # Cancel the invoice if it's posted
                    if order.account_move.state == 'posted':
                        order.account_move.button_draft()
                    # Delete the invoice
                    order.account_move.unlink()
                    _logger.info("✅ Removed existing invoice for order %s", order.id)
                except Exception as e:
                    _logger.error("❌ Error removing existing invoice: %s", str(e))
                    # Continue anyway as the sync should still work
            
            # Step 2: Handle order state - temporarily set to draft if needed
            if order.state in ['paid', 'done', 'invoiced']:
                _logger.info("🔄 Temporarily setting order to draft state for modifications")
                # Use SQL to bypass validation for state change
                self.env.cr.execute("""
                    UPDATE pos_order 
                    SET state = 'draft' 
                    WHERE id = %s
                """, (order.id,))
                # Invalidate the ORM cache for this record
                order.invalidate_recordset(['state'])
            
            # Step 3: Clear existing lines and payments
            _logger.info("🗑️ Clearing existing lines (%d) and payments (%d)", 
                        old_lines_count, old_payment_count)
            order.lines.unlink()
            order.payment_ids.unlink()
            
            # Step 4: Extract lines and payments for special handling
            lines_data = order_vals.pop('lines', [])
            payment_data = order_vals.pop('payment_ids', [])

            # Remove fields that shouldn't be updated on existing orders
            order_vals.pop('name', None)  # Keep original order name
            order_vals.pop('company_id', None)  # Keep original company

            # Update session_id to correct session based on FS number
            order_vals['session_id'] = session.id
            if order.session_id.id != session.id:
                _logger.info("🔄 Updating session from %s to %s based on FS number",
                           order.session_id.name, session.name)

            # Step 5: Update core order fields
            _logger.info("📝 Updating core order fields")
            order.write(order_vals)
            
            # Step 6: Create new lines from invoice
            _logger.info("➕ Creating %d new order lines from invoice", len(lines_data))
            for line_tuple in lines_data:
                # line_tuple is (0, 0, dict)
                line_vals = line_tuple[2]
                line_vals['order_id'] = order.id
                order.lines.create(line_vals)
            
            # Step 7: Create new payments from invoice
            _logger.info("💳 Creating %d new payment(s) from invoice", len(payment_data))
            for payment_tuple in payment_data:
                # payment_tuple is (0, 0, dict)
                payment_vals = payment_tuple[2]
                payment_vals['pos_order_id'] = order.id
                order.payment_ids.create(payment_vals)
            
            # Step 8: Set state to 'invoiced' if order has MRC and FS number
            # Otherwise restore original state
            if order.fiscal_mrc and order.fs_no:
                # Order has fiscal data - should be invoiced
                final_state = 'invoiced'
                _logger.info("🔄 Setting order to 'invoiced' state (has MRC: %s and FS: %s)", 
                            order.fiscal_mrc, order.fs_no)
            elif old_state in ['paid', 'done', 'invoiced']:
                # Restore original state
                final_state = old_state
                _logger.info("🔄 Restoring order to %s state", old_state)
            else:
                # Default to paid if it wasn't already in a final state
                final_state = 'paid'
                _logger.info("🔄 Setting order to 'paid' state")
            
            # Use SQL to bypass validation for state change
            self.env.cr.execute("""
                UPDATE pos_order 
                SET state = %s 
                WHERE id = %s
            """, (final_state, order.id))
            # Invalidate the ORM cache for this record
            order.invalidate_recordset(['state'])
            
            # Step 9: Recompute totals if the method exists
            if hasattr(order, '_compute_total_cost_in_real_time'):
                order._compute_total_cost_in_real_time()
            
            # Step 10: Regenerate picking FIRST (before invoicing locks fields)
            _logger.info("📦 Regenerating picking for updated order %s", order.id)
            try:
                picking = order._regenerate_order_picking()
                if picking:
                    _logger.info("✅ Regenerated %d picking(s) for order %s", len(picking), order.id)
                else:
                    _logger.warning("⚠️ No picking created for order %s", order.id)
            except Exception as e:
                _logger.error("❌ Error regenerating picking: %s", str(e))
                # Continue anyway as the order sync should still be valid

            # Step 11: Create new invoice AFTER picking (and verify link)
            _logger.info("📄 Creating new invoice for updated order %s", order.id)
            try:
                # Create new invoice using the overridden method from pos_order.py
                new_invoice = order.action_pos_order_invoice()

                # CRITICAL: Verify invoice was created and linked
                order.invalidate_recordset(['account_move'])  # Refresh cache
                if not order.account_move:
                    _logger.error("❌ Invoice created but NOT linked to order %s", order.id)
                    # Try to force link if invoice was returned
                    if new_invoice:
                        if hasattr(new_invoice, 'id'):
                            order.write({'account_move': new_invoice.id})
                            _logger.info("✅ Forced invoice link for order %s", order.id)
                        else:
                            _logger.warning("⚠️ Invoice returned but has no ID")
                else:
                    _logger.info("✅ Invoice created and linked: %s (ID: %s)",
                               order.account_move.name, order.account_move.id)

                    # CRITICAL: Update invoice date to match fiscal invoice date
                    fiscal_invoice_date = invoice_data.get('date')
                    if fiscal_invoice_date and order.account_move:
                        try:
                            # Get the invoice date from fiscal data
                            if isinstance(fiscal_invoice_date, str):
                                invoice_date = fields.Date.from_string(fiscal_invoice_date)
                            else:
                                invoice_date = fiscal_invoice_date

                            # Check if invoice date needs updating
                            if order.account_move.date != invoice_date or order.account_move.invoice_date != invoice_date:
                                old_date = order.account_move.date

                                # Update invoice to draft if posted (to allow date change)
                                if order.account_move.state == 'posted':
                                    order.account_move.button_draft()
                                    _logger.info("📝 Set invoice to draft to update date")

                                # Update both date and invoice_date fields
                                order.account_move.write({
                                    'date': invoice_date,
                                    'invoice_date': invoice_date,
                                })

                                # Re-post if it was posted
                                if order.account_move.state == 'draft':
                                    order.account_move.action_post()
                                    _logger.info("📝 Re-posted invoice after date update")

                                _logger.info("📅 Updated invoice date: %s → %s for invoice %s",
                                           old_date, invoice_date, order.account_move.name)
                            else:
                                _logger.info("✅ Invoice date already correct: %s", invoice_date)

                        except Exception as date_error:
                            _logger.error("❌ Failed to update invoice date: %s", str(date_error))

            except Exception as e:
                _logger.error("❌ Error creating new invoice: %s", str(e))
                # Continue anyway as the order sync should still be valid
            
            # Step 12: Log the complete update
            old_info = f'amount: {old_amount:.2f}, lines: {old_lines_count}, payments: {old_payment_count}'
            if old_invoice_id:
                old_info += f', invoice: {old_invoice_id}'
            new_info = f'amount: {order.amount_total:.2f}, lines: {len(order.lines)}, payments: {len(order.payment_ids)}'
            if order.account_move:
                new_info += f', invoice: {order.account_move.id}'
            
            self.env['pos.change.log'].log_change(
                pos_order_id=order.id,
                fs_no=str(invoice_data['fsNumber']).zfill(8),
                fiscal_mrc=order.fiscal_mrc,
                change_type='complete_update',
                old_value=old_info,
                new_value=new_info,
                daily_report_id=daily_report.id
            )
            
            _logger.info("✅ Complete sync successful for order %s", order.id)
            return True
            
        except Exception as e:
            _logger.error("❌ Failed to sync order %s: %s", order.id, str(e))
            import traceback
            _logger.error("Full traceback: %s", traceback.format_exc())
            return False

    def _combine_date_time(self, invoice_date, invoice_time):
        """Combine date and time fields from invoice"""
        if not invoice_time:
            return invoice_date
        
        try:
            # Parse time string (format: "HH:MM:SS")
            time_parts = invoice_time.split(':')
            hour = int(time_parts[0])
            minute = int(time_parts[1]) if len(time_parts) > 1 else 0
            second = int(time_parts[2]) if len(time_parts) > 2 else 0
            
            # Combine with date
            datetime_combined = fields.Datetime.to_datetime(invoice_date)
            datetime_combined = datetime_combined.replace(
                hour=hour, 
                minute=minute, 
                second=second
            )
            return datetime_combined
        except:
            return invoice_date

    def _create_order_from_invoice(self, invoice_data, target_mrc, daily_report):
        """Create new order from invoice data with auto-invoicing support."""
        try:
            # Get invoice record
            invoice_rec = self.env['pos.invoice'].browse(invoice_data['id'])

            # Find appropriate session using FS number BEFORE method (uses invoice.date, not reconciliation date)
            invoice_date = fields.Datetime.from_string(invoice_data['date']).date()
            session = self._find_session_by_fs_before(
                invoice_data['fsNumber'],
                target_mrc,
                invoice_date
            )

            if not session:
                _logger.warning("⚠️ Cannot find/create session for invoice FS %s", invoice_data['fsNumber'])
                return False
            
            # Prepare order values
            order_vals = self._prepare_pos_order_vals(invoice_rec, target_mrc, session.id)
            
            if not order_vals:
                _logger.warning("⚠️ Cannot prepare order values for invoice FS %s", invoice_data['fsNumber'])
                return False
            
            # Create order
            new_order = self.create(order_vals)
            _logger.info("✅ Created order %s (ID: %s) from invoice FS %s",
                        new_order.name, new_order.id, invoice_data['fsNumber'])
            
            # Create inventory movements with detailed logging
            _logger.info("=" * 60)
            _logger.info("ATTEMPTING INVENTORY CREATION for FS %s", invoice_data['fsNumber'])
            _logger.info("Order ID: %s | Order Name: %s", new_order.id, new_order.name)
            _logger.info("=" * 60)
            
            try:
                _logger.info("📦 Starting inventory creation for order %s (FS: %s)", 
                           new_order.id, invoice_data['fsNumber'])
                
                # Ensure config is ready for inventory (inline for now)
                if new_order.session_id and new_order.session_id.config_id:
                    config = new_order.session_id.config_id
                    
                    # Check stock_location_id (required by pos_etta)
                    if not config.stock_location_id:
                        warehouse = self.env['stock.warehouse'].search([
                            ('company_id', '=', new_order.company_id.id)
                        ], limit=1)
                        if warehouse:
                            config.stock_location_id = warehouse.lot_stock_id
                            _logger.info("✅ Set stock_location_id for config %s", config.name)
                    
                    # Check picking_type_id
                    if not config.picking_type_id:
                        picking_type = self.env['stock.picking.type'].search([
                            ('code', '=', 'outgoing'),
                            ('company_id', '=', new_order.company_id.id),
                            ('warehouse_id', '!=', False)
                        ], limit=1)
                        if picking_type:
                            config.picking_type_id = picking_type
                            _logger.info("✅ Set picking_type_id for config %s", config.name)
                
                # Create inventory movements directly using pos_etta
                pickings = False
                
                # Direct pos_etta integration
                if hasattr(self.env['stock.picking'], '_create_picking_from_pos_order_lines'):
                    _logger.info("🔧 Found pos_etta method, creating inventory directly")
                    
                    # Get required data
                    config = new_order.session_id.config_id if new_order.session_id else None
                    if config:
                        picking_type = config.picking_type_id
                        if not picking_type:
                            picking_type = self.env['stock.picking.type'].search([
                                ('code', '=', 'outgoing'),
                                ('company_id', '=', new_order.company_id.id)
                            ], limit=1)
                        
                        if picking_type:
                            # Set location_id on order (pos_etta needs this)
                            if not new_order.location_id and config.stock_location_id:
                                new_order.location_id = config.stock_location_id
                            
                            # Get destination location
                            if new_order.partner_id and new_order.partner_id.property_stock_customer:
                                location_dest_id = new_order.partner_id.property_stock_customer.id
                            else:
                                location_dest_id = picking_type.default_location_dest_id.id
                            
                            # Log all products first
                            _logger.info("📋 Checking products in order:")
                            for line in new_order.lines:
                                product = line.product_id
                                p_type = product.detailed_type if hasattr(product, 'detailed_type') else product.type
                                _logger.info("  - %s: type=%s, qty=%.2f", product.name, p_type, line.qty)
                            
                            # Filter stockable lines
                            stockable_lines = new_order.lines.filtered(
                                lambda l: (
                                    (hasattr(l.product_id, 'detailed_type') and l.product_id.detailed_type in ['product', 'consu']) or
                                    (l.product_id.type in ['product', 'consu'])
                                ) and l.qty != 0
                            )
                            
                            if stockable_lines:
                                _logger.info("📦 Creating inventory for %d stockable lines", len(stockable_lines))
                                _logger.info("  - Picking Type: %s (ID: %s)", picking_type.name, picking_type.id)
                                _logger.info("  - Destination Location ID: %s", location_dest_id)
                                
                                try:
                                    # Call pos_etta method
                                    pickings = self.env['stock.picking']._create_picking_from_pos_order_lines(
                                        location_dest_id=location_dest_id,
                                        lines=stockable_lines,
                                        picking_type=picking_type,
                                        partner=new_order.partner_id
                                    )
                                    
                                    if pickings:
                                        _logger.info("✅ pos_etta created %d picking(s)", len(pickings))
                                        # Link pickings to the order
                                        for picking in pickings:
                                            picking.write({
                                                'pos_order_id': new_order.id,
                                                'origin': new_order.name or new_order.pos_reference
                                            })
                                        _logger.info("🔗 Linked pickings to order %s", new_order.id)
                                except Exception as e:
                                    _logger.error("❌ Error calling pos_etta: %s", str(e))
                            else:
                                _logger.info("⚠️ No stockable products found in order")
                        else:
                            _logger.error("❌ No picking type found")
                    else:
                        _logger.error("❌ No config found in session")
                else:
                    _logger.error("❌ pos_etta method not available")
                    pickings = new_order._create_order_picking()
                
                if pickings:
                    _logger.info("✅ Successfully created %d inventory movement(s) for FS %s", 
                               len(pickings), invoice_data['fsNumber'])
                    for picking in pickings:
                        _logger.info("  - Picking: %s | Type: %s | State: %s", 
                                   picking.name, picking.picking_type_id.name, picking.state)
                else:
                    _logger.info("ℹ️ No inventory movements created for FS %s", invoice_data['fsNumber'])
                    
                    # Check why
                    if not new_order.lines:
                        _logger.info("   Reason: No order lines")
                    elif not new_order.session_id:
                        _logger.info("   Reason: No session")
                    elif not new_order.session_id.config_id.stock_location_id:
                        _logger.info("   Reason: No stock location in config")
                    elif not new_order.session_id.config_id.picking_type_id:
                        _logger.info("   Reason: No picking type in config")
                    else:
                        # Check product types
                        stockable = False
                        for line in new_order.lines:
                            p_type = line.product_id.detailed_type if hasattr(line.product_id, 'detailed_type') else line.product_id.type
                            if p_type in ['product', 'consu']:
                                stockable = True
                                break
                        if not stockable:
                            _logger.info("   Reason: All products are service type")
                        else:
                            _logger.info("   Reason: Unknown - check logs above")
                            
            except Exception as e:
                _logger.error("❌ Exception in inventory creation for FS %s: %s", 
                            invoice_data['fsNumber'], str(e))
                import traceback
                _logger.error("Full traceback: %s", traceback.format_exc())
            
            new_order._compute_total_cost_in_real_time()
            # Log creation
            self.env['pos.change.log'].log_change(
                pos_order_id=new_order.id,
                fs_no=str(invoice_data['fsNumber']).zfill(8),
                fiscal_mrc=target_mrc,
                change_type='recreated',
                old_value='none',
                new_value='created from invoice',
                daily_report_id=daily_report.id
            )
            
            # CRITICAL FIX: ALWAYS create invoice for reconciled orders
            # This ensures the sales detail report shows invoice numbers correctly
            _logger.info("📄 Creating invoice for order FS No: %s (ID: %s)", invoice_data['fsNumber'], new_order.id)
            try:
                # Create invoice using Odoo's standard method
                invoice = new_order.action_pos_order_invoice()

                # CRITICAL: Verify invoice was created and linked
                new_order.invalidate_recordset(['account_move'])  # Refresh cache
                if invoice and new_order.account_move:
                    # Set state to invoiced
                    new_order.write({'state': 'invoiced'})
                    _logger.info("✅ Invoice created and linked: %s (ID: %s) for FS %s",
                               new_order.account_move.name, new_order.account_move.id, invoice_data['fsNumber'])

                    # CRITICAL: Update invoice date to match fiscal invoice date
                    fiscal_invoice_date = invoice_data.get('date')
                    if fiscal_invoice_date and new_order.account_move:
                        try:
                            # Get the invoice date from fiscal data
                            if isinstance(fiscal_invoice_date, str):
                                invoice_date = fields.Date.from_string(fiscal_invoice_date)
                            else:
                                invoice_date = fiscal_invoice_date

                            # Check if invoice date needs updating
                            if new_order.account_move.date != invoice_date or new_order.account_move.invoice_date != invoice_date:
                                old_date = new_order.account_move.date

                                # Update invoice to draft if posted (to allow date change)
                                if new_order.account_move.state == 'posted':
                                    new_order.account_move.button_draft()
                                    _logger.info("📝 Set invoice to draft to update date")

                                # Update both date and invoice_date fields
                                new_order.account_move.write({
                                    'date': invoice_date,
                                    'invoice_date': invoice_date,
                                })

                                # Re-post if it was posted
                                if new_order.account_move.state == 'draft':
                                    new_order.account_move.action_post()
                                    _logger.info("📝 Re-posted invoice after date update")

                                _logger.info("📅 Updated invoice date: %s → %s for invoice %s",
                                           old_date, invoice_date, new_order.account_move.name)
                            else:
                                _logger.info("✅ Invoice date already correct: %s", invoice_date)

                        except Exception as date_error:
                            _logger.error("❌ Failed to update invoice date: %s", str(date_error))

                    # Log invoice creation
                    self.env['pos.change.log'].log_change(
                        pos_order_id=new_order.id,
                        fs_no=str(invoice_data['fsNumber']).zfill(8),
                        fiscal_mrc=target_mrc,
                        change_type='auto_invoiced',
                        old_value='no_invoice',
                        new_value=f"invoice: {new_order.account_move.name}",
                        daily_report_id=daily_report.id
                    )
                else:
                    _logger.error("❌ Invoice creation failed or not linked for FS %s", invoice_data['fsNumber'])
                    # Force link if invoice was returned
                    if invoice and hasattr(invoice, 'id'):
                        new_order.write({
                            'account_move': invoice.id,
                            'state': 'invoiced'
                        })
                        _logger.info("✅ Forced invoice link for order %s", new_order.id)
                    else:
                        # Set to paid state if invoice creation failed
                        new_order.write({'state': 'paid'})
                        _logger.warning("⚠️ Order %s set to 'paid' state (no invoice)", new_order.id)

            except Exception as e:
                _logger.error("❌ Failed to create invoice for FS %s: %s", invoice_data['fsNumber'], str(e))
                # Set to paid state if invoice creation failed
                new_order.write({'state': 'paid'})
                _logger.warning("⚠️ Order %s set to 'paid' state due to invoice error", new_order.id)
            
            return True
            
        except Exception as e:
            _logger.error("❌ Failed to create order from invoice FS %s: %s", 
                         invoice_data['fsNumber'], str(e))
            return False

    def _ensure_pos_config_has_inventory(self, session):
        """Ensure the POS config has inventory settings configured."""
        if not session or not session.config_id:
            return False
        
        config = session.config_id
        
        # Check if picking type is already configured
        if config.picking_type_id:
            _logger.info("✅ POS Config '%s' already has picking type: %s", 
                        config.name, config.picking_type_id.name)
            return True
        
        # Try to find a suitable picking type
        _logger.warning("⚠️ POS Config '%s' missing picking type, attempting to set one", config.name)
        
        # Look for a delivery picking type for the company
        picking_type = self.env['stock.picking.type'].search([
            ('code', '=', 'outgoing'),
            ('company_id', '=', config.company_id.id),
            ('warehouse_id', '!=', False)
        ], limit=1)
        
        if picking_type:
            try:
                config.write({'picking_type_id': picking_type.id})
                _logger.info("✅ Set picking type '%s' for POS config '%s'", 
                           picking_type.name, config.name)
                return True
            except Exception as e:
                _logger.error("❌ Failed to set picking type: %s", str(e))
                return False
        else:
            _logger.error("❌ No suitable picking type found for company %s", config.company_id.name)
            return False
    
    def _find_or_create_session(self, target_mrc, date):
        """Find existing session for the date - prefer open sessions over closed ones."""
        _logger.info("🔍 [Session Lookup] Starting session search for MRC: %s, Date: %s", target_mrc, date)

        # Use the actual date passed, not today's date
        date_start = fields.Datetime.to_datetime(date).replace(hour=0, minute=0, second=0)
        date_end = fields.Datetime.to_datetime(date).replace(hour=23, minute=59, second=59)

        _logger.info("🔍 [Session Lookup] Searching for orders between %s and %s", date_start, date_end)

        # Strategy 1: Find any order from the same day and reuse its session
        order = self.env['pos.order'].search([
            ('fiscal_mrc', '=', target_mrc),
            ('date_order', '>=', date_start),
            ('date_order', '<=', date_end),
            ('session_id', '!=', False)
        ], limit=1, order='date_order asc')

        if order and order.session_id:
            _logger.info("✅ [Session Lookup] Found existing order #%s with session: %s (State: %s)",
                        order.id, order.session_id.name, order.session_id.state)
            return order.session_id

        _logger.info("ℹ️ [Session Lookup] No orders found with sessions, searching for sessions by date...")

        # Strategy 2: Find sessions covering the date - PREFER OPEN SESSIONS
        # First try to find OPEN sessions
        open_sessions = self.env['pos.session'].search([
            ('start_at', '<=', date_end),
            ('state', '=', 'opened'),
        ], limit=1, order='start_at desc')

        if open_sessions:
            _logger.info("✅ [Session Lookup] Found OPEN session: %s (ID: %s)",
                        open_sessions.name, open_sessions.id)
            self._ensure_pos_config_has_inventory(open_sessions)
            return open_sessions

        # Strategy 3: If no open session, find closed session covering the date
        closed_sessions = self.env['pos.session'].with_context(active_test=False).search([
            ('start_at', '<=', date_end),
            ('stop_at', '>=', date_start),
            ('state', '=', 'closed'),
        ], limit=1, order='start_at desc')

        if closed_sessions:
            _logger.info("ℹ️ [Session Lookup] Using CLOSED session: %s (ID: %s)",
                        closed_sessions.name, closed_sessions.id)
            self._ensure_pos_config_has_inventory(closed_sessions)
            return closed_sessions

        # Strategy 4: Last resort - find ANY session covering the date
        any_session = self.env['pos.session'].with_context(active_test=False).search([
            ('start_at', '<=', date_end),
        ], limit=1, order='start_at desc')

        if any_session:
            _logger.warning("⚠️ [Session Lookup] Using fallback session: %s (State: %s)",
                          any_session.name, any_session.state)
            self._ensure_pos_config_has_inventory(any_session)
            return any_session

        _logger.error("❌ [Session Lookup] No session found for MRC %s on %s", target_mrc, date)
        return False

    def _find_session_by_fs_before(self, fs_number, fiscal_mrc, invoice_date):
        """
        Find session by FS number BEFORE, then by invoice date.
        Priority: 1) FS before, 2) invoice.date, 3) date from order before
        NEVER use reconciliation date!
        """
        _logger.info("🔍 [FS Before Lookup] Finding session for FS: %s, MRC: %s, Invoice Date: %s",
                     fs_number, fiscal_mrc, invoice_date)

        # Convert FS to standardized format
        fs_no_str = str(fs_number).zfill(8)

        # Step 1: Find order with FS BEFORE (BEST method - sequential FS numbers)
        order_before = self.env['pos.order'].search([
            ('fiscal_mrc', '=', fiscal_mrc),
            ('fs_no', '!=', False),
            ('fs_no', '<', fs_no_str),
            ('session_id', '!=', False)
        ], limit=1, order='fs_no desc')

        if order_before and order_before.session_id:
            _logger.info("✅ [FS Before Lookup] Found session from FS BEFORE: %s (FS: %s, Date: %s)",
                        order_before.session_id.name,
                        order_before.fs_no,
                        order_before.date_order)
            return order_before.session_id

        # Step 2: Use INVOICE DATE (NOT reconciliation date!)
        if invoice_date:
            _logger.info("ℹ️ [FS Before Lookup] No FS before found, using INVOICE DATE: %s", invoice_date)
            session = self._find_or_create_session(fiscal_mrc, invoice_date)
            if session:
                return session

        # Step 3: Ultra fallback - use date from order before
        if order_before:
            _logger.info("⚠️ [FS Before Lookup] Using date from order before: %s", order_before.date_order)
            fallback_date = order_before.date_order.date() if hasattr(order_before.date_order, 'date') else order_before.date_order
            return self._find_or_create_session(fiscal_mrc, fallback_date)

        _logger.error("❌ [FS Before Lookup] Cannot find session for FS: %s", fs_number)
        return False

    def _cancel_order(self, order, reason, daily_report):
        """Cancel an order with proper logging."""
        try:
            _logger.info("❌ Cancelling order %s: %s", order.id, reason)

            if hasattr(order, 'action_cancel'):
                order.action_cancel()
            else:
                order.write({'state': 'cancel'})

            # Log cancellation
            self.env['pos.change.log'].log_change(
                pos_order_id=order.id,
                fs_no=order.fs_no or 'N/A',
                fiscal_mrc=order.fiscal_mrc or 'N/A',
                change_type='cancelled',
                old_value=f'state: {order.state}',
                new_value=f'cancelled: {reason}',
                daily_report_id=daily_report.id
            )

        except Exception as e:
            _logger.error("❌ Failed to cancel order %s: %s", order.id, str(e))

    def _recalculate_session_balances(self, session_id):
        """
        Recalculate session opening/closing balances after adding/modifying orders.
        This helps understand Expected/Counted/Difference in sales detail report.

        NOTE: This method doesn't actually modify the session (to avoid breaking closed sessions),
        but logs information to help diagnose Expected/Counted/Difference discrepancies.
        """
        if not session_id:
            return False

        session = self.env['pos.session'].browse(session_id)
        if not session:
            _logger.warning("⚠️ Session ID %s not found", session_id)
            return False

        _logger.info("=" * 60)
        _logger.info("SESSION BALANCE ANALYSIS for %s", session.name)
        _logger.info("=" * 60)

        # Get all valid orders in this session
        session_orders = self.search([
            ('session_id', '=', session_id),
            ('state', 'in', ['paid', 'done', 'invoiced'])
        ])

        # Calculate totals from orders
        total_sales = sum(order.amount_total for order in session_orders)
        total_tax = sum(order.amount_tax for order in session_orders)
        total_paid = sum(order.amount_paid for order in session_orders)

        # Count orders with invoices
        orders_with_invoice = session_orders.filtered(lambda o: o.account_move)
        orders_without_invoice = session_orders.filtered(lambda o: not o.account_move)

        _logger.info("📊 Session: %s (State: %s)", session.name, session.state)
        _logger.info("📦 Total Orders: %d", len(session_orders))
        _logger.info("   - With Invoice: %d", len(orders_with_invoice))
        _logger.info("   - Without Invoice: %d", len(orders_without_invoice))
        _logger.info("💰 Total Sales: %.2f", total_sales)
        _logger.info("💰 Total Tax: %.2f", total_tax)
        _logger.info("💰 Total Paid: %.2f", total_paid)

        if session.state == 'closed':
            _logger.warning("⚠️ Session is CLOSED")
            _logger.warning("   Expected/Counted in Sales Detail Report may not match")
            _logger.warning("   because orders were added after session was closed.")
            _logger.info("")
            _logger.info("📝 Sales Detail Report Guidance:")
            _logger.info("   - Expected = %.2f (from orders in this session)", total_sales)
            _logger.info("   - Counted = Session close amount (recorded when session closed)")
            _logger.info("   - Difference = Expected - Counted")
            _logger.info("   - If orders were added AFTER session close, Difference will be non-zero")

        if orders_without_invoice:
            _logger.warning("⚠️ %d orders WITHOUT invoices (will show 'no invoice' in report):",
                          len(orders_without_invoice))
            for order in orders_without_invoice[:5]:  # Show first 5
                _logger.warning("   - Order: %s | FS: %s | State: %s",
                              order.name, order.fs_no or 'N/A', order.state)

        _logger.info("=" * 60)

        return True

    def _prepare_pos_order_vals(self, invoice, fiscal_mrc, session_id):
        """Prepare order values from invoice with complete data mapping and CORRECT DATE/TIME."""
        company_id = self.env.company.id
        session = self.env['pos.session'].browse(session_id)
        
        if not session:
            _logger.warning("⚠️ Invalid session ID: %s", session_id)
            return False

        # Get payment method
        payment_method_id, session_id, _ = self.env['pos.payment.method'].get_payment_method_id(
            invoice.paymentType or 'Cash', company_id, session.id
        )
        
        if not payment_method_id:
            _logger.warning("⚠️ No valid payment method for invoice FS %s", invoice.fsNumber)
            return False

        # Partner lookup
        partner_id = False
        if invoice.buyerName and invoice.buyerName != "Customer":
            partner = self.env['res.partner'].search([('name', '=ilike', invoice.buyerName)], limit=1)
            if partner:
                partner_id = partner.id
        
        # Set default partner if not found (starts with 'walk' or specific customer ID)
        if not partner_id:
            # First try to find a partner starting with 'walk'
            default_partner = self.env['res.partner'].search([('name', '=ilike', 'walk%')], limit=1)
            if not default_partner:
                # If no 'walk' partner found, use the specific customer with ID 1
                # You can change this ID to your desired default customer ID
                default_partner = self.env['res.partner'].browse(1).exists()
            
            if default_partner:
                partner_id = default_partner.id

        # Employee lookup
        employee_id = False
        if invoice.cashierName:
            employee = self.env['hr.employee'].search([('name', '=ilike', invoice.cashierName)], limit=1)
            if employee:
                employee_id = employee.id
        
        company_id = invoice.device_id.company_id.id if invoice.device_id else self.env.company.id
        
        # Combine date and time for accurate order datetime
        order_datetime = self._combine_date_time(invoice.date, invoice.time)

        # Prepare order lines
        order_lines = []
        for line in invoice.line_ids:
            if not line.itemName:
                continue
            
            # Product lookup with better matching
            product = None
            _logger.info("Searching for product: '%s' (PLU: %s)", line.itemName, line.pluCode)

            # First priority: PLU code exact match
            if line.pluCode and line.pluCode != '0000':
                product = self.env['product.product'].search([
                    ('default_code', '=', line.pluCode),
                    ('company_id', 'in', [company_id, False])  # Company specific or shared
                ], limit=1)
                if product:
                    _logger.info("Found product by PLU code: %s", product.name)

            # Second priority: Exact name match
            if not product and line.itemName:
                product = self.env['product.product'].search([
                    ('name', '=', line.itemName),
                    ('company_id', 'in', [company_id, False])
                ], limit=1)
                if product:
                    _logger.info("Found product by exact name: %s", product.name)

            # Third priority: Case-insensitive exact match
            if not product and line.itemName:
                product = self.env['product.product'].search([
                    ('name', '=ilike', line.itemName),
                    ('company_id', 'in', [company_id, False])
                ], limit=1)
                if product:
                    _logger.info("Found product by case-insensitive name: %s", product.name)

            # Fourth priority: More controlled partial match
            if not product and line.itemName:
                # Try with the full name as a partial match but require more specificity
                product = self.env['product.product'].search([
                    ('name', 'ilike', f'%{line.itemName}%'),
                    ('company_id', 'in', [company_id, False])
                ], limit=1)
                if product:
                    _logger.info("Found product by partial match: %s", product.name)

            if not product:
                _logger.warning(
                    "⚠️ No close product match found in company %s: %s (PLU: %s)",
                    company_id, line.itemName, line.pluCode
                )
                continue
            
            # Use tax from product configuration
            tax_ids = []
            
            # Get taxes from the product itself
            if product and product.taxes_id:
                # Filter taxes for the correct company
                product_taxes = product.taxes_id.filtered(lambda t: t.company_id.id == company_id)
                if product_taxes:
                    tax_ids = product_taxes.ids
                    tax_names = ', '.join(product_taxes.mapped('name'))
                    _logger.info("✅ Using product's configured taxes: %s for product %s", 
                               tax_names, product.name)
                else:
                    # Try to use any tax configured on the product
                    if product.taxes_id:
                        tax_ids = product.taxes_id.ids
                        tax_names = ', '.join(product.taxes_id.mapped('name'))
                        _logger.info("✅ Using product's taxes (any company): %s for product %s", 
                                   tax_names, product.name)
            
            # Log invoice vs product tax comparison
            tax_amount = line.lineTotalWithTax - line.lineTotal if line.lineTotalWithTax and line.lineTotal else 0
            _logger.info("Tax comparison - Product: %s | Invoice Tax Rate: %s | Invoice Tax Amount: %.2f | Product Taxes: %s",
                        product.name, line.taxRate, tax_amount, 
                        ', '.join(self.env['account.tax'].browse(tax_ids).mapped('name')) if tax_ids else "None")
            
            # Calculate correct price_unit (should be price without tax for tax-exclusive systems)
            if tax_amount > 0:
                # Price is tax-inclusive, extract base price
                price_unit_without_tax = line.lineTotal / line.quantity if line.quantity else line.price
            else:
                price_unit_without_tax = line.price
            
            _logger.info("✅ Product ready for order line: %s (ID: %s) | Price: %.2f | Taxes: %s", 
                        product.name, product.id, price_unit_without_tax, 
                        ', '.join(self.env['account.tax'].browse(tax_ids).mapped('name')) if tax_ids else "None")
            
            order_lines.append((0, 0, {
                'product_id': product.id,
                'full_product_name': product.name or line.itemName,
                'qty': line.quantity,
                'price_unit': price_unit_without_tax,  # Use price without tax
                'price_subtotal': line.lineTotal,
                'price_subtotal_incl': line.lineTotalWithTax,
                'tax_ids': [(6, 0, tax_ids)] if tax_ids else False,  # Use product's tax configuration
            }))

        if not order_lines:
            _logger.warning("⚠️ No valid lines for invoice FS %s", invoice.fsNumber)
            return False

        # Log payment information for debugging
        _logger.info("Payment details for FS %s: Total: %.2f | Tax: %.2f | Paid: %.2f | Change: %.2f",
                    invoice.fsNumber, 
                    invoice.totalWithTax or 0,
                    invoice.totalTax or 0,
                    invoice.totalPaid or 0,
                    invoice.change or 0)
        
        # SIMPLIFIED FIX: Always use totalWithTax as amount_paid for consistency
        # This ensures the payment amount matches the invoice total
        amount_paid = invoice.totalWithTax
        _logger.info("💰 Setting amount_paid to totalWithTax: %.2f (was totalPaid: %.2f)",
                     invoice.totalWithTax, invoice.totalPaid or 0.0)

        # Prepare note explaining order creation context (minimal, clean note)
        order_note = f"Fiscal reconciliation - Invoice FS {invoice.fsNumber}"

        return {
            'name': session.config_id.name,
            'fs_no': str(invoice.fsNumber).zfill(8),
            'fiscal_mrc': fiscal_mrc,
            'ej_checksum': invoice.checksum,
            'pos_reference': invoice.referenceNumber,
            'amount_total': invoice.totalWithTax,
            'amount_tax': invoice.totalTax or 0.0,
            'amount_paid': amount_paid,
            'amount_return': invoice.change or 0.0,
            'date_order': order_datetime,  # Use combined date/time
            'partner_id': partner_id,
            'session_id': session_id,
            'company_id': company_id,
            'employee_id': employee_id,
            'lines': order_lines,
            'payment_ids': [(0, 0, {
                'payment_method_id': payment_method_id,
                'amount': amount_paid,  # Now always equals totalWithTax
                'payment_date': order_datetime,  # Use combined date/time
            })] if payment_method_id else [],
            'note': order_note,  # Add note explaining reconciliation context
        }
    @api.model
    def check_duplicate_fs(self, mrc, date):
        """Utility method to check for duplicate FS numbers."""
        if isinstance(date, str):
            date = datetime.strptime(date, "%Y-%m-%d").date()
        
        groups = self.read_group(
            domain=[
                ('fs_no', '!=', False),
                ('fiscal_mrc', '=', mrc),
                ('date_order', '>=', date),
                ('date_order', '<=', date),
                ('state', 'in', ['paid', 'done'])
            ],
            fields=['fs_no'],
            groupby=['fs_no'],
            lazy=False
        )
        
        duplicates = [(g['fs_no'], g['__count']) for g in groups if g['__count'] > 1]
        
        if duplicates:
            _logger.info("Found %d duplicate FS numbers for MRC %s on %s", len(duplicates), mrc, date)
            for fs_no, count in duplicates:
                _logger.info("  FS %s: %d occurrences", fs_no, count)
        else:
            _logger.info("No duplicate FS numbers found for MRC %s on %s", mrc, date)
        
        return duplicates
    
    @api.model
    def queue_daily_reconciliation_all_companies(self):
        """Public wrapper for daily reconciliation - can be called via XML-RPC"""
        return self._queue_daily_reconciliation_all_companies()
    
    @api.model
    def _queue_daily_reconciliation_all_companies(self):
        """Queue reconciliation jobs for all companies using existing logic"""
        companies = self.env['res.company'].search([])
        job_uuids = []
        
        for company in companies:
            devices = self.env['pos.device'].search([
                ('company_id', '=', company.id),
            ])
            
            for device in devices:
                if 'queue.job' in self.env:
                    # Queue a job for each device with staggered execution
                    delay_minutes = len(job_uuids) * 2  # 2 minutes between each job
                    
                    # Use existing run_reconciliation_check with auto-invoice context
                    job = self.with_company(company).with_context(
                        auto_invoice_created=True
                    ).with_delay(
                        priority=20,
                        eta=fields.Datetime.now() + timedelta(minutes=delay_minutes),
                        description=f'Daily Reconciliation: {company.name} - {device.name}'
                    ).run_reconciliation_check(
                        target_mrc=device.mrc,
                        start_date=fields.Date.today(),
                        end_date=fields.Date.today()
                    )
                    
                    job_uuids.append(job.uuid)
                    _logger.info(f"Queued reconciliation for {company.name} - {device.name}: Job {job.uuid}")
                else:
                    # Direct execution if queue_job not available
                    try:
                        self.with_company(company).with_context(
                            auto_invoice_created=True
                        ).run_reconciliation_check(
                            target_mrc=device.mrc,
                            start_date=fields.Date.today(),
                            end_date=fields.Date.today()
                        )
                        _logger.info(f"Completed reconciliation for {company.name} - {device.name}")
                    except Exception as e:
                        _logger.error(f"Failed reconciliation for {company.name} - {device.name}: {str(e)}")
        
        # Send summary email
        if 'queue.job' in self.env:
            # Queue a summary job to run after all reconciliations
            summary_delay = len(job_uuids) * 2 + 10  # After all jobs + 10 minutes
            self.with_delay(
                priority=25,
                eta=fields.Datetime.now() + timedelta(minutes=summary_delay),
                description='Daily Reconciliation Summary'
            )._send_daily_reconciliation_summary(fields.Date.today())
        else:
            self._send_daily_reconciliation_summary(fields.Date.today())
        
        return job_uuids if job_uuids else True
    
    def _send_daily_reconciliation_summary(self, target_date):
        """Send summary email after all reconciliations complete"""
        # Fetch all daily reports for today
        daily_reports = self.env['pos.daily.report'].search([
            ('date', '=', target_date)
        ])
        
        if not daily_reports:
            _logger.warning("No daily reports found for %s", target_date)
            return
        
        # Prepare summary data
        summary_html = f"""
        <h3>Daily Reconciliation Summary - {target_date}</h3>
        <table border="1" style="border-collapse: collapse; width: 100%;">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>MRC</th>
                    <th>Orders</th>
                    <th>Invoices</th>
                    <th>Order Total</th>
                    <th>Invoice Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
        """
        
        for report in daily_reports:
            status_color = 'green' if report.reconciliation_status == 'completed' else 'red'
            summary_html += f"""
                <tr>
                    <td>{report.company_id.name}</td>
                    <td>{report.fiscal_mrc}</td>
                    <td>{report.pos_order_count}</td>
                    <td>{report.invoice_count}</td>
                    <td>{report.net_order_total:.2f}</td>
                    <td>{report.net_invoice_total:.2f}</td>
                    <td style="color: {status_color};">{report.reconciliation_status}</td>
                </tr>
            """
        
        summary_html += """
            </tbody>
        </table>
        """
        
        # Send email to administrators
        self._send_reconciliation_email(summary_html)
        
        return True
    
    def _send_reconciliation_email(self, content):
        """Send reconciliation summary email"""
        try:
            # Get admin users
            admin_users = self.env['res.users'].search([
                ('groups_id', 'in', self.env.ref('base.group_system').id)
            ])
            
            if admin_users:
                email_to = ','.join(admin_users.mapped('email'))
                
                mail_values = {
                    'subject': f'Daily POS Reconciliation Report - {fields.Date.today()}',
                    'body_html': content,
                    'email_to': email_to,
                    'email_from': self.env.company.email or 'noreply@company.com',
                }
                self.env['mail.mail'].create(mail_values).send()
                _logger.info("Reconciliation summary email sent to administrators")
        except Exception as e:
            _logger.error("Failed to send reconciliation email: %s", str(e))


class PosDailyReport(models.Model):
    _name = 'pos.daily.report'
    _description = 'POS Daily Report'
    _order = 'date desc, fiscal_mrc'

    date = fields.Date(string='Date', required=True, default=fields.Date.today)
    fiscal_mrc = fields.Char(string='Fiscal MRC', required=True, index=True)
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    
    # Counts
    pos_order_count = fields.Integer(string='POS Order Count')
    invoice_count = fields.Integer(string='Invoice Count')
    refund_count = fields.Integer(string='Refund Count')
    unmatched_fs_count = fields.Integer(string='Unmatched FS Count')
    
    # Totals
    session_total = fields.Float(string='Session Total', digits=(16, 2))
    z_report_total = fields.Float(string='Z Report Total', digits=(16, 2))
    refund_total = fields.Float(string='Refund Total', digits=(16, 2))
    net_order_total = fields.Float(string='Net Order Total', digits=(16, 2))
    net_invoice_total = fields.Float(string='Net Invoice Total', digits=(16, 2))
    zreport_sales_total = fields.Float(string='Z-Report Sales Total', digits=(16, 2))
    zreport_refund_total = fields.Float(string='Z-Report Refund Total', digits=(16, 2))
    net_zreport_total = fields.Float(string='Net Z-Report Total', digits=(16, 2))
    total_mismatch = fields.Float(string='Total Mismatch', digits=(16, 2))
    
    # Change counts
    recreated_orders = fields.Integer(string='Recreated Orders')
    updated_orders = fields.Integer(string='Updated Orders')
    cancelled_orders = fields.Integer(string='Cancelled Orders', compute='_compute_cancelled_orders')
    
    # Relations
    change_log_ids = fields.One2many('pos.change.log', 'daily_report_id', string='Change Logs')
    
    # Status
    reconciliation_status = fields.Selection([
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('failed', 'Failed')
    ], string='Status', default='pending')
    
    @api.depends('change_log_ids')
    def _compute_cancelled_orders(self):
        for report in self:
            report.cancelled_orders = len(report.change_log_ids.filtered(lambda l: l.change_type == 'cancelled'))


class PosZReportException(models.Model):
    _name = 'pos.zreport.exception'
    _description = 'POS Z-Report Exception Configuration'
    _order = 'date desc'

    date = fields.Date(string='Date', required=True, index=True)
    fiscal_mrc = fields.Char(string='Fiscal MRC', required=True, index=True)
    zreport_id = fields.Integer(string='Z-Report ID to Exclude')
    reason = fields.Text(string='Reason for Exclusion')
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    active = fields.Boolean(string='Active', default=True)

    @api.model
    def get_excluded_zreport_ids(self, fiscal_mrc, start_date, end_date):
        """Get list of Z-report IDs to exclude for the given date range and MRC."""
        exceptions = self.search([
            ('fiscal_mrc', '=', fiscal_mrc),
            ('date', '>=', start_date),
            ('date', '<=', end_date),
            ('active', '=', True),
            ('company_id', '=', self.env.company.id)
        ])
        return [exc.zreport_id for exc in exceptions if exc.zreport_id]


class PosChangeLog(models.Model):
    _name = 'pos.change.log'
    _description = 'POS Change Log'
    _order = 'date desc'

    date = fields.Datetime(string='Change Date', default=fields.Datetime.now, index=True)
    pos_order_id = fields.Many2one('pos.order', string='POS Order', index=True)
    fs_no = fields.Char(string='FS Number', index=True)
    fiscal_mrc = fields.Char(string='Fiscal MRC', index=True)
    change_type = fields.Selection([
        ('recreated', 'Order Recreated'),
        ('amount_updated', 'Amount Updated'),
        ('cancelled', 'Order Cancelled'),
        ('linked', 'Order Linked'),
        ('updated_from_invoice', 'Updated from Invoice'),
        ('complete_update', 'Complete Update'),
        ('auto_invoiced', 'Auto Invoiced'),
    ], string='Change Type', required=True)
    old_value = fields.Char(string='Old Value')
    new_value = fields.Char(string='New Value')
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    daily_report_id = fields.Many2one('pos.daily.report', string='Daily Report', index=True)

    @api.model
    def log_change(self, pos_order_id, fs_no, fiscal_mrc, change_type, old_value=None, new_value=None, daily_report_id=False):
        """Log a change made during reconciliation."""
        _logger.info("📝 Logging change: Order %s, FS %s, Type: %s", pos_order_id, fs_no, change_type)
        return self.create({
            'pos_order_id': pos_order_id,
            'fs_no': fs_no,
            'fiscal_mrc': fiscal_mrc,
            'change_type': change_type,
            'old_value': old_value,
            'new_value': new_value,
            'company_id': self.env.company.id,
            'daily_report_id': daily_report_id,
        })